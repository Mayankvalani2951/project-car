﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
           string sql="insert into Usertbl values('"+uid.Text+"','"+uname.Text+"','"+upass.Text+"')";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            getdata();
            MessageBox.Show("Done");
            

        }
        private void getdata()
        {
            string sql = "select * from Usertbl";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void User_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carrentalDataSet1.Usertbl' table. You can move, or remove it, as needed.
            this.usertblTableAdapter.Fill(this.carrentalDataSet1.Usertbl);

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
           string sql = "delete from Usertbl where id='" + uid.Text + "'";
           SqlDataAdapter da = new SqlDataAdapter( sql,Class1.cn);
           DataTable dt = new DataTable();
            da.Fill(dt);
            getdata();
            MessageBox.Show("Your data deleted");
           
        }
    }
}
